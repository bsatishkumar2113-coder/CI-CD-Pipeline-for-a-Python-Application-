# CI/CD Pipeline for a Python Application

A Flask app containerized with Docker, with a GitHub Actions pipeline that
runs tests, builds the image, and pushes it to GitHub Container Registry (GHCR)
on every push to `main`.

## Pipeline flow

    push -> test (pytest) -> build image (Buildx + cache) -> push to GHCR
                             (only runs if tests pass)

## Run locally

    pip install -r requirements-dev.txt
    pytest
    docker build -t python-cicd .
    docker run -p 8000:8000 python-cicd
    curl localhost:8000/health

## Setup

1. Create a GitHub repo and push this project to `main`.
2. In Settings > Actions > General, set Workflow permissions to "Read and write".
3. Push a commit. The image appears under your repo's Packages tab.
(To use Docker Hub instead, swap the login step to use DOCKERHUB_USERNAME /
DOCKERHUB_TOKEN secrets and change the image tags.)

## Resume bullets

- Built a CI/CD pipeline with GitHub Actions that runs automated tests, builds a
  Docker image, and publishes it to GHCR on every push, eliminating manual releases.
- Containerized a Python app with a multi-stage, non-root Dockerfile, reducing
  image size by X% and ensuring consistent builds across environments.
- Automated test, build, and publish stages with pytest, Docker Buildx, and layer
  caching, cutting build time from X to Y minutes.

## Interview prep

- Why tag with the commit SHA and `latest`? Traceability and easy rollbacks.
- Why does build depend on test? Never publish an untested image.
- How are credentials handled? Built-in GITHUB_TOKEN / repo secrets, never hardcoded.
- Why multi-stage and non-root? Smaller attack surface and smaller image.
- Next steps: linting (ruff), Trivy vulnerability scan, automated deploy to a
  server or Kubernetes, semantic version tags.
